# LVGL Arduino Necklace Status

This project is an Arduino-based wearable display prototype using the LVGL graphics library. It is designed for a smart necklace that displays real-time status updates or visuals on a 1.69" LCD screen.

## 🧩 Features
- Custom GUI using **LVGL**
- Audio playback via **PCM5101 module**
- Touch input via **SPD2010 screen**
- Battery monitoring
- Gyroscope (QMI8658)
- SD card file loading
- Wireless connectivity

## 🔧 Hardware Requirements
- **ESP32 development board**
- **1.69" SPD2010 LCD display**
- **Touch interface compatible with SPD2010**
- **PCM5101 Audio DAC**
- **TCA9554 for power control**
- **MicroSD card module**
- **QMI8658 gyroscope (optional)**
- **Battery and speaker**

## 📁 File Overview

| File | Purpose |
|------|---------|
| `LVGL_Arduino_Necklace_status.ino` | Main Arduino sketch |
| `LVGL_Driver.*` | LVGL display driver |
| `Display_SPD2010.*`, `esp_lcd_spd2010.*` | Display-specific drivers |
| `LVGL_Music.*` | Music demo / playback |
| `Audio_PCM5101.*` | Audio DAC interface |
| `PWR_Key.*`, `TCA9554PWR.*`, `BAT_Driver.*` | Power and battery control |
| `Wireless.*` | Network functionality |
| `Touch_SPD2010.h`, `Gyro_QMI8658.h` | Touch & motion interfaces |

## ⚙️ Software Setup

1. Install Arduino IDE
2. Add **ESP32 board support** from Board Manager
3. Install required libraries:
   - `lvgl`
   - `Wire`
   - `SPI`
   - `SD`
4. Open `LVGL_Arduino_Necklace_status.ino` and upload to board

## 📌 Notes
This is a hardware-heavy prototype. Ensure your wiring matches the drivers and libraries used.

---

